# Installation Android (version de développement)

Cette archive contient le code source et un workflow GitHub Actions qui peut construire un APK debug. Elle ne contient pas encore d'APK compilé.

1. Créer un dépôt GitHub privé et y téléverser les fichiers de ce dossier.
2. Vérifier que le workflow « Build Android debug APK » s'exécute dans Actions.
3. Quand l'exécution est terminée avec succès, ouvrir l'exécution et télécharger l'artefact `MySIQ-Planner-debug-APK`.
4. Extraire l'archive téléchargée : elle contient `app-debug.apk`.
5. Transférer l'APK sur le téléphone Android et l'ouvrir. Android peut demander d'autoriser temporairement l'installation depuis cette source.

C'est un APK debug de test, non signé pour une publication Play Store. Pour une diffusion durable, générer une version release et la signer avec une clé privée conservée hors du dépôt.
