import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = { appId: 'com.mysiq.planner', appName: 'MySIQ Planner', webDir: 'dist', bundledWebRuntime: false, plugins: { LocalNotifications: { smallIcon: 'ic_stat_icon_config_sample', iconColor: '#6d5ce8' } } };
export default config;
