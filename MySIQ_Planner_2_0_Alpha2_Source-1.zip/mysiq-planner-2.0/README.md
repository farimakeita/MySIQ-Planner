# MySIQ Planner 2.0 — Alpha 1

Alpha 1 améliorée : PWA responsive, données locales persistantes, tableau de bord enrichi (prochain cours, prochaine révision, temps d'étude validé et compte à rebours du coucher), planning hebdomadaire avec modification/suppression et détection des chevauchements, objectifs, progression XP non répétable par objectif, suivi manuel des cinq prières, notes par matière, thème clair/sombre et minuteur Pomodoro.

## Lancer sur ordinateur
- Node.js 20+ recommandé.
- `npm install`
- `npm run dev`
- Ouvrir l'adresse locale affichée par Vite.
- `npm run build` produit `dist/`.

## Installer comme PWA sur Android
Déployer le contenu `dist/` sur un hébergement HTTPS, ouvrir l'URL avec Chrome Android puis choisir « Installer l'application » / « Ajouter à l'écran d'accueil ». Le service worker fournit un cache de base. Le premier chargement nécessite Internet.

## Préparer Android natif (APK)
- `npm install`
- `npm run build`
- `npx cap add android`
- `npx cap sync android`
- `npx cap open android`
Puis construire un APK debug depuis Android Studio. Un APK compilé n'est pas fourni dans cette archive.

## État réel des fonctions
| Fonction | État Alpha 1 |
|---|---|
| Dashboard et navigation | Fonctionnels ; indicateurs journaliers, prochain cours/révision et repos |
| Matières et notes locales | Fonctionnels |
| Planning cours/TD/TP | Fonctionnel : ajout, modification, suppression, contrôle des heures et détection de chevauchements |
| Objectifs, cases à cocher, XP | Fonctionnels |
| Pomodoro | Fonctionnel tant que l'app reste ouverte |
| Prières | Suivi manuel seulement ; aucun horaire calculé |
| Notifications planifiées en arrière-plan | Non implémentées |
| Import PDF/image et extraction | Non implémentés |
| Professeur IA / RAG / OCR / citations | Non implémentés |
| Illustrations IA | Non implémentées ; icône/personnage décoratif uniquement |
| Authentification / cloud / synchronisation | Non implémentés |

## Architecture cible
- Frontend : React/TypeScript à industrialiser ; l'alpha actuelle est un frontend TypeScript léger avec Vite pour valider les flux locaux.
- Android : Capacitor 7 (configuration incluse ; plugins Preferences et Local Notifications installés lors de `npm install`).
- Backend futur : Node.js + API, PostgreSQL, stockage privé, pipeline d'extraction/OCR, RAG avec références document/page, fournisseur LLM côté serveur.

## Sécurité IA
Ne jamais embarquer de clé API dans l'application mobile ou le frontend. Les documents privés doivent être envoyés à un backend authentifié, avec consentement, politique de conservation/suppression et contrôle d'accès. L'IA devra séparer les citations issues des fichiers des explications générales.

## Données
L'alpha utilise localStorage dans le navigateur. L'adaptateur Capacitor Preferences est sélectionné sur Android natif. Export JSON et suppression locale sont disponibles dans Paramètres.

## Vérification de cette itération
- Le code a été relu et les règles de gestion du planning (horaires valides et absence de chevauchement) ont été ajoutées.
- La compilation Vite complète n'a pas pu être confirmée dans cet environnement : l'installation des dépendances npm a expiré. Les imports Capacitor nécessitent `npm install` avant la compilation.
- Les heures de prière et les notifications en arrière-plan restent explicitement hors périmètre de cette itération.
