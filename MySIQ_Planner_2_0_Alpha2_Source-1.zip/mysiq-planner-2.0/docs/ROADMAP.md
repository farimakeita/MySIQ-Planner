# Roadmap de réalisation

1. Alpha 1 (présente) : socle local, tableau de bord, matières, planning, objectifs, Pomodoro, suivi manuel des prières.
2. Alpha 2 : tests automatisés, formulaires plus complets, import de calendrier et notifications Android natives avec permissions.
3. Backend : authentification, PostgreSQL, sauvegarde/synchronisation, gestion des documents.
4. Professeur IA : extraction PDF/DOCX/PPTX, OCR, chunking, embeddings, recherche RAG, citations fichier/page, modes guidé et entraînement.
5. Visuels : génération d'illustrations originales et diagrammes déterministes vérifiables.
6. Spiritualité : source de calcul documentée, choix ville/méthode, validation des horaires, rappels configurables.
7. Académie Web/Mobile : parcours progressif, exercices, projets et suivi.
8. Android release : tests appareils, permissions, alarmes, signature et APK/AAB.

## Critères de validation avant chaque version
- Les données survivent à un redémarrage.
- Les formulaires valident les champs et empêchent les incohérences horaires.
- Les fonctions non connectées sont explicitement signalées.
- Aucun horaire de prière ni citation religieuse n'est inventé.
- Aucun secret fournisseur n'est inclus dans le client.

## Itération Alpha 1 — tableau de bord et planning
- Dashboard : indicateurs du jour, prochaine séance universitaire, prochaine révision, durée d'étude validée, temps avant l'heure de coucher souhaitée.
- Planning : ajout, édition, suppression et détection de créneaux qui se chevauchent.
- XP : chaque objectif ne rapporte ses points qu'une seule fois, même si la case est décochée puis recochée.
- Validation : revue statique effectuée ; build complet à exécuter après installation des dépendances.
